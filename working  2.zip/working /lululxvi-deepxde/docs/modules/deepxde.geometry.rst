deepxde.geometry package
========================

Submodules
----------

deepxde.geometry.csg module
---------------------------

.. automodule:: deepxde.geometry.csg
    :members:
    :undoc-members:
    :show-inheritance:

deepxde.geometry.geometry module
--------------------------------

.. automodule:: deepxde.geometry.geometry
    :members:
    :undoc-members:
    :show-inheritance:

deepxde.geometry.geometry\_1d module
------------------------------------

.. automodule:: deepxde.geometry.geometry_1d
    :members:
    :undoc-members:
    :show-inheritance:

deepxde.geometry.geometry\_2d module
------------------------------------

.. automodule:: deepxde.geometry.geometry_2d
    :members:
    :undoc-members:
    :show-inheritance:

deepxde.geometry.geometry\_nd module
------------------------------------

.. automodule:: deepxde.geometry.geometry_nd
    :members:
    :undoc-members:
    :show-inheritance:

deepxde.geometry.timedomain module
----------------------------------

.. automodule:: deepxde.geometry.timedomain
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: deepxde.geometry
    :members:
    :undoc-members:
    :show-inheritance:
