deepxde.data package
====================

Submodules
----------

deepxde.data.data module
------------------------

.. automodule:: deepxde.data.data
    :members:
    :undoc-members:
    :show-inheritance:

deepxde.data.dataset module
---------------------------

.. automodule:: deepxde.data.dataset
    :members:
    :undoc-members:
    :show-inheritance:

deepxde.data.func module
------------------------

.. automodule:: deepxde.data.func
    :members:
    :undoc-members:
    :show-inheritance:

deepxde.data.func\_constraint module
------------------------------------

.. automodule:: deepxde.data.func_constraint
    :members:
    :undoc-members:
    :show-inheritance:

deepxde.data.helper module
--------------------------

.. automodule:: deepxde.data.helper
    :members:
    :undoc-members:
    :show-inheritance:

deepxde.data.ide module
-----------------------

.. automodule:: deepxde.data.ide
    :members:
    :undoc-members:
    :show-inheritance:

deepxde.data.mf module
----------------------

.. automodule:: deepxde.data.mf
    :members:
    :undoc-members:
    :show-inheritance:

deepxde.data.op\_dataset module
-------------------------------

.. automodule:: deepxde.data.op_dataset
    :members:
    :undoc-members:
    :show-inheritance:

deepxde.data.pde module
-----------------------

.. automodule:: deepxde.data.pde
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: deepxde.data
    :members:
    :undoc-members:
    :show-inheritance:
